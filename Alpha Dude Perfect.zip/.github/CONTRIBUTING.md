# Contributing
Contributions to Dude Perfect are always appreciated, whether it be improvements to the documentation or new features, please feel free to make the change. Contact our developers on  [**Discord**](https://discord.gg/ZzbZpdw) before you get started.
